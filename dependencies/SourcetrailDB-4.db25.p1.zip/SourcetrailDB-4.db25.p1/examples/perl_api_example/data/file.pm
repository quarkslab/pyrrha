package MyClass;

my $my_member = 1;

sub my_method {
	return $my_member;
}
