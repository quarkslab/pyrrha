
class MyType:

	my_member = true

	def my_method():
		return my_member
